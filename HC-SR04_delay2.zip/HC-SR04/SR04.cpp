
#include "SR04.h"

SR04::SR04(int echoPin_1,int triggerPin_1,int echoPin_2,int triggerPin_2,int echoPin_3,int triggerPin_3) {
    _echoPin_1 = echoPin_1;
    _triggerPin_1 = triggerPin_1;
    _echoPin_2 = echoPin_2;
    _triggerPin_2 = triggerPin_2;
    _echoPin_3 = echoPin_3;
    _triggerPin_3 = triggerPin_3;
    pinMode(_echoPin_1, INPUT);
    pinMode(_triggerPin_1, OUTPUT);
    pinMode(_echoPin_2, INPUT);
    pinMode(_triggerPin_2, OUTPUT);
    pinMode(_echoPin_3, INPUT);
    pinMode(_triggerPin_3, OUTPUT);
    _autoMode = false;
    _distance = 999;
}


// long SR04::Distance() {
//     long d = 0;
//     _duration = 0;
//     digitalWrite(_triggerPin, LOW);
//     delayMicroseconds(2);
//     digitalWrite(_triggerPin, HIGH);
//     delayMicroseconds(10);
//     digitalWrite(_triggerPin, LOW);
//     delayMicroseconds(2);
//     _duration = pulseIn(_echoPin, HIGH, PULSE_TIMEOUT);
//     d = MicrosecondsToCentimeter(_duration);
//     delay(25);
//     return d;
// }

void SR04::Distance(long *d1, long *d2, long *d3) {
    *d1 = 0;
    _duration = 0;
    digitalWrite(_triggerPin_1, LOW);
    delayMicroseconds(2);
    digitalWrite(_triggerPin_1, HIGH);
    delayMicroseconds(10);
    digitalWrite(_triggerPin_1, LOW);
    delayMicroseconds(2);
    _duration = pulseIn(_echoPin_1, HIGH, PULSE_TIMEOUT);
    *d1 = MicrosecondsToCentimeter(_duration);
    delay(2);

    *d2 = 0;
    _duration = 0;
    digitalWrite(_triggerPin_2, LOW);
    delayMicroseconds(2);
    digitalWrite(_triggerPin_2, HIGH);
    delayMicroseconds(10);
    digitalWrite(_triggerPin_2, LOW);
    delayMicroseconds(2);
    _duration = pulseIn(_echoPin_2, HIGH, PULSE_TIMEOUT);
    *d2 = MicrosecondsToCentimeter(_duration);
    delay(2);

    *d3 = 0;
    _duration = 0;
    digitalWrite(_triggerPin_3, LOW);
    delayMicroseconds(2);
    digitalWrite(_triggerPin_3, HIGH);
    delayMicroseconds(10);
    digitalWrite(_triggerPin_3, LOW);
    delayMicroseconds(2);
    _duration = pulseIn(_echoPin_3, HIGH, PULSE_TIMEOUT);
    *d3 = MicrosecondsToCentimeter(_duration);
    delay(25);
}

long SR04::DistanceAvg(int wait, int count) {
    long min, max, avg, d;
    min = 999;
    max = 0;
    avg = d = 0;

    if (wait < 25) {
        wait = 25;
    }

    if (count < 1) {
        count = 1;
    }

    for (int x = 0; x < count + 2; x++) {
        // d = Distance();

        if (d < min) {
            min = d;
        }

        if (d > max) {
            max = d;
        }

        avg += d;
    }

    // substract highest and lowest value
    avg -= (max + min);
    // calculate average
    avg /= count;
    return avg;
}

void SR04::Ping() {
    // _distance = Distance();
}

long SR04::getDistance() {
    return _distance;
}

long SR04::MicrosecondsToCentimeter(long duration) {
    long d = (duration * 100) / 5882;
    //d = (d == 0)?999:d;
    return d;
}




